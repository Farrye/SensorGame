package com.josericardojunior.touchapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Handler;
import android.view.View;

public class SensorBall extends View implements SensorEventListener {
    Handler handler;
    final int DELAY_TIME = 60;
    int x = 100;
    int y = 100;
    int accelX, accelY, accelZ;
    Runnable gameLoop;
    Paint paint;

    public SensorBall(Context context) {
        super(context);

        handler = new Handler();

        paint = new Paint();
        paint.setColor(Color.RED);

        gameLoop = new Runnable() {
            @Override
            public void run() {
                update();
                invalidate();
            }
        };

    }

    private void update(){

        float w = getWidth();
        float h = getHeight();

        float c_x = w / 2.0f;
        float c_y = h / 2.0f;

        float ratio_x = w / 100.0f;
        float ratio_y = h / 100.0f;

        x = (int) (c_x - accelX * ratio_x);
        y = (int) (c_y + accelY * ratio_y);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawCircle(x, y, 100, paint);

        handler.postDelayed(gameLoop, DELAY_TIME);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        switch (sensorEvent.sensor.getType()){

            case Sensor.TYPE_ACCELEROMETER:
                accelX = (int) sensorEvent.values[0];
                accelY = (int) sensorEvent.values[1];
                accelZ = (int) sensorEvent.values[2];
                break;
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
