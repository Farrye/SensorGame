package com.josericardojunior.touchapp;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.Chronometer;

public class MainActivity extends AppCompatActivity {

    SensorBall ball;
    Sensor accel_sensor;
    SensorManager sensorManager;
    Chronometer chronometer;
    private boolean finishRun = false;
    private long pauseOffset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        chronometer = (Chronometer) findViewById(R.id.Timer);

        sensorManager = (SensorManager)
               getSystemService(SENSOR_SERVICE);

       accel_sensor =
               sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        ball = (SensorBall)findViewById(R.id.Sensor_Ball_View);

    }

    @Override
    protected void onResume() {
        super.onResume();

        BeginChronometer();
        RestartChronometer();
    }

    @Override
    protected void onStart() {
        super.onStart();
        sensorManager.registerListener(ball, accel_sensor,
                SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onStop() {
        super.onStop();
        FinishChronometer();
        sensorManager.unregisterListener(ball);
    }

    private void BeginChronometer(){
        if(!finishRun){
            chronometer.setBase(SystemClock.elapsedRealtime() - pauseOffset);
            chronometer.start();
            finishRun = true;
        }
    }

    private void FinishChronometer(){
        if(finishRun){
            chronometer.stop();
            pauseOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
        }
    }

    private void RestartChronometer(){
        if(finishRun){
            finishRun = !finishRun;
        }
    }
}