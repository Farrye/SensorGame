package com.josericardojunior.touchapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class SensorBall extends View implements SensorEventListener {
    Handler handler;
    final int DELAY_TIME = 60;
    int x;
    int y;
    int accelX, accelY, accelZ;
    float speed = 7f;
    Runnable gameLoop;
    Bitmap bmp, bmpWall;

    Rect playerRect;
    List<Collider> colliderList = new ArrayList<>();

    public SensorBall(Context context, AttributeSet attrs) {
        super(context, attrs);

        handler = new Handler();

        bmp = BitmapFactory.decodeResource(getResources(),
                R.drawable.hero);
        bmpWall = BitmapFactory.decodeResource(getResources(),
                R.drawable.muro);

        x = 350;
        y = 1500;

        colliderList.add(new Collider(0, 200, bmpWall.getWidth(), bmpWall.getHeight(), 0.2f));
        colliderList.add(new Collider(0, 50, bmpWall.getWidth(), bmpWall.getHeight(), 0.5f));

        gameLoop = new Runnable() {
            @Override
            public void run() {
                update();
                invalidate();
            }
        };
    }

    private void update(){
        //float ratio_x = w / 100.0f;
        //float ratio_y = h / 100.0f;

        for (Collider c : colliderList) {
            if (c.Collide(playerRect))
            {
                x = 350;
                y = 1500;
                return;
            }
        }
        x -= (int) (accelX * speed);
        y += (int) (accelY * speed);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Player
        Rect src = new Rect();
        src.left = 0;
        src.top = 0;
        src.right = bmp.getWidth();
        src.bottom = bmp.getHeight();

        playerRect = new Rect();
        playerRect.left = x;
        playerRect.top = y;
        playerRect.right = playerRect.left + (int)(bmp.getWidth() * 0.2f);
        playerRect.bottom = playerRect.top + (int)(bmp.getHeight() * 0.2f);

        canvas.drawBitmap(bmp, src, playerRect,null);

        //Wall

        Rect srcWall = new Rect();
        srcWall.left = 0;
        srcWall.top = 0;
        srcWall.right = bmpWall.getWidth();
        srcWall.bottom = bmpWall.getHeight();

        for (Collider c : colliderList) {
            Rect dstWall = new Rect();
            dstWall.left = (int)c.x;
            dstWall.top = (int)c.y;
            dstWall.right = dstWall.left + (int)(bmpWall.getWidth() * c.scale);
            dstWall.bottom = dstWall.top + (int)(bmpWall.getHeight() * c.scale);

            canvas.drawBitmap(bmpWall, srcWall, dstWall, null);
        }

        handler.postDelayed(gameLoop, DELAY_TIME);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        switch (sensorEvent.sensor.getType()){

            case Sensor.TYPE_ACCELEROMETER:
                accelX = (int) sensorEvent.values[0];
                accelY = (int) sensorEvent.values[1];
                accelZ = (int) sensorEvent.values[2];
                break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
