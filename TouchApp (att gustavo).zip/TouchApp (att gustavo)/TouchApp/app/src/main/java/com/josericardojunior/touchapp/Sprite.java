package com.josericardojunior.touchapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Handler;
import android.view.View;

public class Sprite extends View {
    Bitmap bmp;
    Handler handler;
    final int DELAY_TIME = 60;
    int x = 100;
    Runnable gameLoop;

    public Sprite(Context context) {
        super(context);

        bmp = BitmapFactory.decodeResource(getResources(),
                R.drawable.hero);

        handler = new Handler();

        gameLoop = new Runnable() {
            @Override
            public void run() {
                x = x + 1;
                invalidate();
            }
        };
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Rect src = new Rect();
        src.left = 0;
        src.top = 0;
        src.right = bmp.getWidth();
        src.bottom = bmp.getHeight();

        Rect dst = new Rect();
        dst.left = x;
        dst.top = 200;
        dst.right = dst.left + (int)(bmp.getWidth() * 0.2f);
        dst.bottom = dst.top + (int)(bmp.getHeight() * 0.2f);

        canvas.drawBitmap(bmp, src, dst,null);

        handler.postDelayed(gameLoop, DELAY_TIME);
    }
}
