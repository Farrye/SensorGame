package com.josericardojunior.touchapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class MyView extends View implements View.OnTouchListener {
    Paint paint;
    int x = 200;
    int y = 200;
    int oldX = -1;
    int oldY = -1;
    List<Point> circulos = new ArrayList<>();


    public MyView(Context context) {
        super(context);

        paint = new Paint();
        paint.setColor(Color.RED);
        setOnTouchListener(this);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        for (Point p : circulos)
            canvas.drawCircle(p.x, p.y, 100, paint);
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {

        int action = motionEvent.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            circulos.clear();
            x = oldX = (int) motionEvent.getX();
            y = oldY = (int) motionEvent.getY();
            Point p = new Point(x, y);
            circulos.add(p);
            invalidate();
            return true;

        } else if (action == MotionEvent.ACTION_MOVE){
            x = (int) motionEvent.getX();
            y = (int) motionEvent.getY();

            if (x != oldX || y != oldY) {
                oldX = x; oldY = y;
                Point p = new Point(x, y);
                circulos.add(p);
                invalidate();
            }
            return true;
        }

        return false;
    }
}
