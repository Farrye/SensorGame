package com.josericardojunior.touchapp;

import android.graphics.Rect;
import android.widget.Chronometer;

public class Collider {

    Rect rect;

    float x;
    float y;

    float w;
    float h;

    float scale;
    boolean isFinish;

    public Collider(float x, float y, float w, float h, float scale) {
        this.x = x;
        this.y = y;
        this.w = w * scale;
        this.h = h * scale;
        this.scale = scale;

        rect = new Rect();
        rect.left = (int) x;
        rect.top = (int) y;
        rect.right = (int)(x + w);
        rect.bottom = (int)(y + h);

    }

    public boolean Collide(Rect player) {
        if (player.intersect(rect)) {
            return true;
        } else {
            return false;
        }
    }
}
